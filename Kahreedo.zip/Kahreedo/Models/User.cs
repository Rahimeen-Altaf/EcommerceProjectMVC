﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kahreedo.Models
{
    public static class _User
    {
        public static int _usrID { get; set; }
        public static string _usrName { get; set; }
        public static string _Email { get; set; }
        public static int _OrderID { get; set; }
        public static bool _firstTime { get; set; }
    }
}